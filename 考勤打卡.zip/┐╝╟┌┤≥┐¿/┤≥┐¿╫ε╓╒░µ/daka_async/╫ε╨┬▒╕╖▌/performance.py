# performance.py - 性能监控和优化工具
import time
import psutil
import asyncio
import logging
from functools import wraps
from typing import Any, Callable, Dict, Optional
from datetime import datetime, timedelta
from collections import defaultdict
import weakref

logger = logging.getLogger("GroupCheckInBot")


class PerformanceMonitor:
    """性能监控器"""

    def __init__(self):
        self.metrics = defaultdict(list)
        self.slow_operations = []
        self.start_time = time.time()

    def track_operation(self, operation_name: str):
        """操作性能追踪装饰器"""
        def decorator(func: Callable) -> Callable:
            @wraps(func)
            async def async_wrapper(*args, **kwargs):
                start_time = time.time()
                start_memory = self.get_memory_usage()

                try:
                    result = await func(*args, **kwargs)
                    return result
                except Exception as e:
                    raise e
                finally:
                    duration = time.time() - start_time
                    memory_used = self.get_memory_usage() - start_memory

                    # 记录指标
                    self.metrics[f"{operation_name}_time"].append(duration)
                    self.metrics[f"{operation_name}_memory"].append(memory_used)

                    # 记录慢操作
                    if duration > 5.0:  # 5秒阈值
                        self.slow_operations.append({
                            "operation": operation_name,
                            "duration": duration,
                            "memory_used": memory_used,
                            "timestamp": datetime.now(),
                        })
                        logger.warning(
                            f"🐌 慢操作: {operation_name} 耗时 {duration:.2f}s, 内存使用 {memory_used:.1f}MB"
                        )

                    # 定期报告
                    if len(self.metrics[f"{operation_name}_time"]) % 100 == 0:
                        self._report_metrics(operation_name)

            @wraps(func)
            def sync_wrapper(*args, **kwargs):
                start_time = time.time()
                start_memory = self.get_memory_usage()

                try:
                    return func(*args, **kwargs)
                finally:
                    duration = time.time() - start_time
                    memory_used = self.get_memory_usage() - start_memory
                    self.metrics[f"{operation_name}_time"].append(duration)

                    if duration > 1.0:
                        logger.info(f"⏱️ {operation_name} 耗时: {duration:.2f}s")

            return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper

        return decorator

    def get_memory_usage(self) -> float:
        """获取内存使用量(MB)"""
        process = psutil.Process()
        return process.memory_info().rss / 1024 / 1024

    def _report_metrics(self, operation_name: str):
        """报告指标统计"""
        times = self.metrics.get(f"{operation_name}_time", [])
        if times:
            avg_time = sum(times) / len(times)
            max_time = max(times)
            logger.info(
                f"📊 {operation_name} 统计: 平均 {avg_time:.3f}s, 最大 {max_time:.3f}s, 样本数 {len(times)}"
            )

    def get_performance_report(self) -> Dict[str, Any]:
        """获取性能报告"""
        report = {
            "uptime": time.time() - self.start_time,
            "memory_usage_mb": self.get_memory_usage(),
            "slow_operations_count": len(self.slow_operations),
            "metrics_summary": {},
        }

        for key, values in self.metrics.items():
            if values:
                report["metrics_summary"][key] = {
                    "count": len(values),
                    "avg": sum(values) / len(values),
                    "max": max(values),
                    "min": min(values),
                }

        return report


class MemoryAwareTaskManager:
    """内存感知的任务管理器"""

    def __init__(self, max_memory_mb: int = 400):
        self.max_memory_mb = max_memory_mb
        self._tasks = weakref.WeakValueDictionary()
        self._task_count = 0

    async def create_task(self, coro, name: Optional[str] = None) -> asyncio.Task:
        """在内存安全的情况下创建任务"""
        # 检查内存使用
        if not self.memory_usage_ok():
            await self.cleanup_tasks()

        # 如果内存仍然紧张，等待
        retry_count = 0
        while not self.memory_usage_ok() and retry_count < 3:
            logger.warning(f"⚠️ 内存紧张，等待清理... (尝试 {retry_count + 1}/3)")
            await asyncio.sleep(2)
            retry_count += 1

        task = asyncio.create_task(coro)
        self._task_count += 1

        if name:
            self._tasks[name] = task
        else:
            self._tasks[f"task_{self._task_count}"] = task

        return task

    def memory_usage_ok(self) -> bool:
        """检查内存使用是否正常"""
        try:
            process = psutil.Process()
            memory_mb = process.memory_info().rss / 1024 / 1024
            return memory_mb < self.max_memory_mb
        except:
            return True

    async def cleanup_tasks(self):
        """清理已完成的任务"""
        completed_tasks = []
        for name, task in list(self._tasks.items()):
            if task.done():
                completed_tasks.append(name)
                try:
                    await task  # 获取结果，确保异常被处理
                except Exception as e:
                    logger.error(f"任务 {name} 执行异常: {e}")

        for name in completed_tasks:
            if name in self._tasks:
                del self._tasks[name]

        if completed_tasks:
            logger.info(f"🧹 清理了 {len(completed_tasks)} 个已完成任务")


class RetryManager:
    """智能重试管理器"""

    def __init__(self, max_retries: int = 3, base_delay: float = 1.0):
        self.max_retries = max_retries
        self.base_delay = base_delay

    async def execute_with_retry(
        self, coro, operation_name: str = "", retry_exceptions: tuple = (Exception,)
    ) -> Any:
        """带重试的执行"""
        last_exception = None

        for attempt in range(self.max_retries):
            try:
                return await coro
            except retry_exceptions as e:
                last_exception = e
                if attempt < self.max_retries - 1:
                    delay = self.base_delay * (2**attempt)  # 指数退避
                    logger.warning(
                        f"⚠️ {operation_name} 第 {attempt + 1} 次失败，{delay:.1f}秒后重试: {e}"
                    )
                    await asyncio.sleep(delay)
                else:
                    break
            except Exception as e:
                # 不重试非预期异常
                logger.error(f"❌ {operation_name} 遇到非重试异常: {e}")
                raise e

        logger.error(
            f"❌ {operation_name} 重试{self.max_retries}次后失败: {last_exception}"
        )
        raise last_exception


class AsyncCache:
    """异步缓存实现"""

    def __init__(self, default_ttl: int = 300):
        self._cache = {}
        self._cache_ttl = {}
        self._default_ttl = default_ttl
        self._lock = asyncio.Lock()
        self._hits = 0
        self._misses = 0

    async def get(self, key: str) -> Any:
        """获取缓存值"""
        async with self._lock:
            if key in self._cache_ttl and time.time() < self._cache_ttl[key]:
                self._hits += 1
                return self._cache.get(key)
            else:
                self._misses += 1
                if key in self._cache:
                    del self._cache[key]
                if key in self._cache_ttl:
                    del self._cache_ttl[key]
                return None

    async def set(self, key: str, value: Any, ttl: Optional[int] = None):
        """设置缓存值"""
        async with self._lock:
            ttl = ttl or self._default_ttl
            self._cache[key] = value
            self._cache_ttl[key] = time.time() + ttl

    async def delete(self, key: str):
        """删除缓存值"""
        async with self._lock:
            if key in self._cache:
                del self._cache[key]
            if key in self._cache_ttl:
                del self._cache_ttl[key]

    async def clear_expired(self):
        """清理过期缓存"""
        async with self._lock:
            now = time.time()
            expired_keys = [
                key for key, expiry in self._cache_ttl.items() if now >= expiry
            ]
            for key in expired_keys:
                if key in self._cache:
                    del self._cache[key]
                if key in self._cache_ttl:
                    del self._cache_ttl[key]

            if expired_keys:
                logger.info(f"🧹 清理了 {len(expired_keys)} 个过期缓存")

    def get_stats(self) -> Dict[str, Any]:
        """获取缓存统计"""
        total = self._hits + self._misses
        hit_rate = self._hits / total if total > 0 else 0
        return {
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": hit_rate,
            "size": len(self._cache),
            "total_operations": total,
        }


class MessageDeduplicator:
    """消息去重器"""

    def __init__(self, ttl: int = 60):
        self._processing = set()
        self._ttl = ttl
        self._timestamps = {}

    def is_duplicate(self, message) -> bool:
        """检查消息是否重复"""
        msg_key = f"{message.chat.id}-{message.message_id}"

        # 清理过期记录
        now = time.time()
        expired_keys = [
            key
            for key, timestamp in self._timestamps.items()
            if now - timestamp > self._ttl
        ]
        for key in expired_keys:
            if key in self._processing:
                self._processing.remove(key)
            if key in self._timestamps:
                del self._timestamps[key]

        if msg_key in self._processing:
            return True

        self._processing.add(msg_key)
        self._timestamps[msg_key] = now
        return False

    def mark_completed(self, message):
        """标记消息处理完成"""
        msg_key = f"{message.chat.id}-{message.message_id}"
        if msg_key in self._processing:
            self._processing.remove(msg_key)


def message_deduplicate(func):
    """消息去重装饰器"""
    deduplicator = MessageDeduplicator()

    @wraps(func)
    async def wrapper(message, *args, **kwargs):
        if deduplicator.is_duplicate(message):
            logger.debug(f"跳过重复消息: {message.chat.id}-{message.message_id}")
            return
        try:
            return await func(message, *args, **kwargs)
        finally:
            deduplicator.mark_completed(message)

    return wrapper


# 全局性能监控实例
performance_monitor = PerformanceMonitor()
task_manager = MemoryAwareTaskManager()
retry_manager = RetryManager()
global_cache = AsyncCache()


# 便捷装饰器
def track_performance(operation_name: str):
    return performance_monitor.track_operation(operation_name)


def with_retry(operation_name: str = "", max_retries: int = 3):
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            local_retry_manager = RetryManager(max_retries=max_retries)
            return await local_retry_manager.execute_with_retry(
                func(*args, **kwargs), operation_name=operation_name or func.__name__
            )

        return wrapper

    return decorator